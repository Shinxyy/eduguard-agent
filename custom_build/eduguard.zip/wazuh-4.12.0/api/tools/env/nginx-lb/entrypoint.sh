#!/usr/bin/env bash

exec nginx -g 'daemon off;'
