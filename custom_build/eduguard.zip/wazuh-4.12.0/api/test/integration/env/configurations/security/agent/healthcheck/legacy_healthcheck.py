# No checks are needed as security tests don't depend on agents
exit(0)
